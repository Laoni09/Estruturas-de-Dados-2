Integrantes: Laôni Moreira (RA 2569140), Juan Peres (RA 2523248)

Considerações: 
1 - na função freeTree(), consideramos que o conteúdo do nodo não será nulo;
2 - ao final da main(), demos free(content) porque um novo endereço de memória foi alocado ao sair do case '+', o qual não é liberado no freeTree(), já que o último endereço alocado não vai para a árvore. 
